# Contractly — Generador de contratos con IA para freelancers

## Descripción
Micro-SaaS que genera contratos, propuestas y NDAs profesionales para freelancers en España, usando IA (Claude de Anthropic).

## Stack
- HTML + CSS + JS puro (sin frameworks — despliegue instantáneo)
- API de Anthropic (Claude) para generación de documentos
- Vercel para hosting gratuito
- Stripe para pagos (a añadir en fase 2)

---

## Despliegue en Vercel (10 minutos, gratis)

### Paso 1 — Sube a GitHub
1. Crea un repo en github.com (ej: `contractly`)
2. Sube el archivo `index.html`

### Paso 2 — Conecta Vercel
1. Ve a vercel.com → "New Project"
2. Importa tu repo de GitHub
3. Pulsa "Deploy" — listo

### Paso 3 — Añade tu API key de Anthropic
1. Ve a console.anthropic.com → API Keys → crea una key
2. En Vercel: Settings → Environment Variables → añade:
   - Name: `ANTHROPIC_API_KEY`
   - Value: `sk-ant-...`
3. En `index.html` línea ~270: `const ANTHROPIC_API_KEY = 'sk-ant-TU_KEY_AQUI';`

> ⚠️ Para producción, mueve la API key a un backend (Vercel Functions) para no exponerla en el frontend.

---

## Backend seguro (opcional pero recomendado)

Crea `/api/generate.js` en tu proyecto de Vercel:

```javascript
export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();

  const { prompt } = req.body;

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1200,
      messages: [{ role: 'user', content: prompt }]
    })
  });

  const data = await response.json();
  res.json({ text: data.content[0].text });
}
```

Luego en `index.html` cambia la llamada a:
```javascript
const res = await fetch('/api/generate', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ prompt })
});
const data = await res.json();
output.textContent = data.text;
```

---

## Monetización con Stripe

### Paso 1 — Cuenta Stripe
- stripe.com → Create account (gratis)
- Activa "Test mode" para pruebas

### Paso 2 — Crea un producto
- Stripe Dashboard → Products → Add product
- Nombre: "Contractly Pro"
- Precio: €9/mes (recurring)
- Copia el `price_id`

### Paso 3 — Payment link (más fácil)
- Stripe → Payment Links → Create link
- Selecciona tu producto Pro
- Pega el link en el botón "Activar Pro" del HTML

### Paso 4 — Webhook (para activar acceso)
- Stripe → Webhooks → Add endpoint: `https://tudominio.vercel.app/api/webhook`
- Evento: `checkout.session.completed`
- Guarda el `signing_secret`

---

## Costes estimados

| Servicio | Coste |
|----------|-------|
| Vercel hosting | Gratis (hasta 100GB bandwidth) |
| API Anthropic | ~€0.003 por documento generado |
| Stripe | 1.4% + €0.25 por transacción |
| Dominio .es | ~€10/año (opcional) |

**Con 50 usuarios Pro:** €450/mes ingresos, ~€15/mes costes = €435 neto.

---

## Próximos pasos sugeridos

1. **Semana 1:** Despliega en Vercel con tu API key → comparte en Reddit r/freelance y r/spain
2. **Semana 2:** Añade Stripe Payment Link al botón Pro
3. **Semana 3:** Backend seguro (Vercel Functions) + autenticación básica (Supabase Auth)
4. **Mes 2:** Export a PDF, plantillas guardadas, branding personalizado

---

## Canales de adquisición (sin ads)

- Reddit: r/freelance, r/Entrepreneur, r/Spain, r/forotrabajoespana
- Product Hunt: lanza como "Contractly — AI contracts for Spanish freelancers"
- SEO: "contrato freelance España", "NDA español gratis", "propuesta comercial plantilla"
- Grupos Telegram: freelancers España, diseñadores España, developers España
